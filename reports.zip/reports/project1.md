Final Report for Project 1: Threads
===================================


## Task 1 changes:

We call `wake_threads(currentTime)` to wake up sleeping threads during `timer_interrupt()` instead of doing so in `schedule()`, because `timer_interrupt()` is called on every tick and the sleeping threads are woken up based on whether their `time_to_wake_up` is lower than or equal to the current time.

## Task 2 changes:

* In the `struct thread`, we added a `list_elem donor_elem` which represents the threads that are waiting to down a semaphore. We made this change because `elem` is already part of the another list.  
* At the end of the `thread_set_priority()`, we made the current thread yield the CPU if it is no longer has the highest priority among running/ready threads 
* Similarly, after we create a new thread, if the newly spawned thread has higher priority than the current thread, then the current thread yield the CPU.
* To modularize the work for task 2, we created multiple helper functions to make the code readable and understandable for debugging. Most of these helper function were used in `synch.c`:

	- `void yield_if_not_max(void)` : 

	> Checks if the current thread has the highest priority among running/ready threads. Yield the CPU if it isn't.

	- `void donate_priority(void)` : 

	> Updates the priority for the current thread.

	- `void add_donors(struct semaphore *sema)`: 
	
	> If the current thread acquire more locks, then the donor list of the thread must be updated. 

	- `void remove_donors(struct lock* lock)`: 
	
	> Remove lock's waiters from holder during lock release.

	- `bool cond_priority_cmp (const struct list_elem *a_, const struct list_elem *b_,void* aux UNUSED)`:
	
	> Compares two elements by priority. Returns `true` if a's priority is lower than b's priority, and `false` otherwise.

	- `bool priority_cmp(const struct list_elem *a_, const struct list_elem *b_, void *aux UNUSED)`:
	
	> Returns true if A's priority is less than B's priority, false otherwise.

## Task 3 changes:

In `thread_set_priority()` : we checked the flag thread_mflqs to make sure we only set the priority only when the mode is not thread_mlfqs.

* We added some helper functions to modularize the calculation for `load_avg`, `recent_cpu`:
	- `void thread_compute_load_avg()` : 
	
	> load_avg = (59/60) × load_avg + (1/60) × ready_threads
	
	- `void thread_compute_priority(struct thread * t, void* aux UNUSED)`:
	
	> priority = PRI_MAX − (recent_cpu/4) − (nice × 2)
	
	- `void thread_compute_recent_cpu(struct thread * t, void* aux UNUSED)`: 
	
	> Recent_cpu = (2 × load_avg)/(2 × load_avg + 1) × recent_cpu + nice
	
	- `void thread_mlfqs_updates(struct thread * t, int64_t current_time, int64_t timer_freq)`:
	
	> Performs updates every on every tick. Used for MLFQ Scheduling.

## Reflection
What went well overall and what went wrong?

* Our initial design was solid, as we had a pretty good understanding of the tasks to be done; most of our time spent debugging came as a result of us missing details in the project specifications.  Debugging non-deterministic behavior was particularly frustrating. For most of us, it was our first experience dealing with a multi-threaded program, so it was hard for us to track where the issue that causing the failure because the code was concurrent not linear. 

* We struggled a little with the list API espcially recognizing the difference between `list_elem` and `elem`. However, after reading some of the provided code and observing how `list_elem` and `elem` are used, we were able to recongize the differences.

* Another diffculty that we face is using the debugger. Debugging Pintos was very hard to do. Particularly, when we `step in` to a function, it was very challenging to verify the correctness of the values we were displaying in the debugger. Moreover, we found that tests were easier to debug if they actually had a `*.c` file, because we could set a breakpoint in the test file before stepping into the code. 

* The list API was very confusing; it took a very long time to understand the list's functionality. 


## Participation of each member:

* Denny: code review, brainstorming, coding, debugging.
* Khang: code review, brainstorming, coding, debugging.
* Elvis: code review, brainstorming, coding, debugging.
* Ahmed: code review, brainstorming, coding, debugging.

We feel that all members contributed equally to the project. We made it a priority to do group coding rather than splitting the tasks among members and merging the work later. In fact, we took turns coding in the same room, using a single computer. Our workflow was as follows: one person writes code and the others check the code's logic and correctness. Upon finding a bug, we all start debugging the code on different machines and whoever finds the bug, fixes it and commits the changes. Then, we all come back as a group to discuss the bug we found and document it if the patch is fully correct.





