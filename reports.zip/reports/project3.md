### Asuna-chan


# Final Report for Project 3: File System

### Task 1 Changes:

- We initialize our cache in `thread/init.c` by calling `cache_init()`
- On `find_block()`, we realize that one of our cases in the eviction policy is repetitive; we don't need to check if the `valid` bit is 0 at all. If the `used` bit is 0, that block can already be considered for eviction.
- To check the cache preformance in testcase cases, we add two global variables `cache_misses` and `cache_hits` to compute the misses and hits. We also added `cache_reset()`, `get_Cache_Misses()` and `get_Cache_Hits()` as helper functions for the test cases. 
    - `cache_reset()` : Reset the cache to cold state by writing back all dirty blocks and resetting cache metadata.
    -  `get_Cache_Misses()`: Returns the number of cache misses.
    -  `get_Cache_Hits()`: Returns the number of cache hits.
- We call `cache_reset()` in `filesys_done()` to make sure we write back dirty blocks back to disk upon system shutdown.

### Task 2 changes:
- The helper function `free_map_allocate_helper(...)` was instead brought to `inode.c` and renamed it `allocate_helper(...)`. It now takes also the `inode_disk` for which we are allocating the new blocks. Also, we decided to pass in `layer`, which is either 0, 1, or 2 to indicate the starting layer to allocate for. `layer = 0` is used for allocating blocks pointed by direct pointers, `layer = 1` is for blocks pointed by the indirect pointer, and `layer = 2` for blocks pointed by the doubly-indirect pointer. Moreover, we pass in the starting indices `singly_index` and `doubly_index` which tells us which index in the indirect blocks should we place the sector number at. 
- Similarly, we moved the function `free_map_release_helper(...)` to `inode.c` and renamed it `release_helper(...)`. In this function we simply go through all the pointers in the inode and free them. 

- We added a helper function called `get_next_data_block(...)` which returns which data block is going to be allocated next. We use this to find `layer`, `singly-index`, and `doubly-index` which are used in `allocate_helper(...)`.

- We added `has_free_space(...)` in `inode.c` to calculate the total number of sectors we need to allocate, including indirect blocks, and check with the free map if there are enough free blocks to create/extend the underlying file.


### Task 3 changes:

- Changed `struct inode * cwd` to `struct dir * cwd` for easier access to the current working directory.

- Remove `struct dir* parent` in `struct inode`, because we found that there is no need for this pointer to support `..`. Instead, we stored a directory entry for `..` which we set when we create a directory.
- Added the helper function `get_dir(...)` which resolves the given path. It takes the current working directory `cwd`, the target path `char * name` , and `struct dir ** parent_dir`, where we place the directory where we would look up the specific file (next to last directory in the path). The function breaks the given name into sequence of directories using the given helper function `get_next_part(char*, char**)`.`get_dir(...)` first checks the validity of the path using `dir_lookup(...)`. If valid, opens the directory and moves to the next part the of path. On the other hand if there is no `next_part` the function saves the parent directory in `parent_dir` variable and returns the name of the target file/directory.
- To implement `chdir`, we create a new function `bool filesys_chdir(const char *path)` in `filesys.c`. We use `get_dir` to resolve the path to this directory, and if it exists, we update the current working directory.

- To implement `mkdir`, we add a boolean to the implementation in `filesys_create` in `filesys.c` in order to identify if we are creating a file or a directory. In the case of it being a directory, we also add the directory entries for `.` and `..` to the directory.


- To implement`readdir`, we use ```bool dir_readdir(struct dir*, char name[NAME_MAX + 1]){...}``` in `directory.c` directly. 


- In the `open(...)` syscall, we change the implementation toward using helper function `get_dir(...)` in `filesys_open(...)`.  If the returned `name` and `parent_dir` both are not NULL, then continue`dir_lookup(...)` to get the targeted inode associated with the targeted file/directory we want to open. From there we use `file_open(...)` to open the file.

- In `remove(...)` syscall, we follow the same implementation as `open(...)` syscall. We use `get_dir(...)` to resolve the path, and from the returned name of targeted directory and the `parent_dir` we use `dir_remove(...)` to remove the target directory. 


- In close(...) syscall, we abstract the implemention in `inode_close(...)`. Thus, we only call `file_close(...)` which calls `inode_close(...)` to take care of everyting. 




### Reflection:

**What did go well and what did go wrong in the design?**

Our design provided a really good starting point as a high level overview. However, we quickly discovered that the implementation details were extremely complicated. For example, tasks like extending an inode, allocating new sectors for data, and parsing file paths to get the directory where the action would be performed were abstracted away in our design document. These proved to be the most time consuming tasks as we had to be aware of small details.


**Participation of group:**

-   Denny: code review, brainstorming, coding, debugging.
    
-   Khang: code review, brainstorming, coding, debugging.
    
-   (Elvis) Kin: code review, brainstorming, coding, adding test cases.
    
-   Ahmed: code review, brainstorming, coding, adding test cases.
    

We feel that all members contributed equally to the project. We prioritized group coding rather than splitting the tasks among members and merging the work later. This was extremely important for this project because all parts are related to each other. We took turns coding in the same room, using a single computer. Our workflow was as follows: one person writes code and the rest checks the code's logic and correctness. Upon finding a bug, we all start debugging the code on different machines and whoever finds the bug, fixes it and commits the changes. Then, we all come back as a group to discuss the bug we found and document its fix.

--------------------------------------------------------


# Testing Report:


### Test cases:

#### Test_Case 1:
- This test case tests the buffer cache’s ability to coalesce writes to the same sector. Each block device keeps a `read_cnt` counter and a `write_cnt` counter. Write a large file byte-by-byte (make the total file size at least 64KB, which is twice the maximum allowed buffer cache size). Then, read it in byte-by-byte. The total number of device writes should be on the order of 128 (because 64KB is 128 blocks).

- In this test, we are expecting the the number `write_cnt` without cache implementation to be very large, yet with cache implementation `write_cnt` should be an order of 128. 
    
- Test case name: `coal-ws-se`
    
- Expected output:

```
(coal-ws-se) begin
(coal-ws-se) create "TESTFILE"
(coal-ws-se) open "TESTFILE"
(coal-ws-se) WRITING INTO TESTFILE..
(coal-ws-se) CLOSING TESTFILE...
(coal-ws-se) open "TESTFILE"
(coal-ws-se) READING FROM TESTFILE..
(coal-ws-se) CLOSING TESTFILE...
(coal-ws-se) PASS
(coal-ws-se) end
EOF
pass;
```

- RESULT:

```
PASS
```

    
    
#### Test_Case 2:
- This test case tests cache’s effectiveness by measuring its cache hit rate. First, reset the buffer cache. Open a file and read it sequentially, to determine the cache hit rate for a cold cache. Then, close it, re-open it, and read it sequentially again, to make sure that the cache hit rate improves.

- We are expecting that when we calculate the `hit_rate` for a cold cache to be way less than that of a hot cache. Since we are reading a file of the same size of the buffer cache (64 blocks) the `hit_rate` of a cold cache should be 0%, while `hit_rate` of a hot cache should be 100% assuming every block of the file still in the cache when we start accessing the file the second time.

- Test case name: `mcache_hits`
    
- Expected output:
```
(mcache_hits) begin
(mcache_hits) create "TESTFILE"
(mcache_hits) open "TESTFILE"
(mcache_hits) WRITING INTO TESTFILE
(mcache_hits) 1st TIME OPENING TESTFILE TO MAKE SEQUENTIAL READ!!
(mcache_hits) open "TESTFILE"
(mcache_hits) RESETTING CACHE BUFFER!!
(mcache_hits) CLOSING TESTFILE
(mcache_hits) COLD CACHE: STATISTICS
(mcache_hits) 2nd TIME REOPENING TESTFILE TO MAKE SEQUENTIAL READ!!
(mcache_hits) open "TESTFILE"
(mcache_hits) CLOSING TESTFILE
(mcache_hits) REMOVING TESTFILE
(mcache_hits) HOT CACHE: STATISTICS
(mcache_hits) PASS
(mcache_hits) end
EOF
pass;
```

- Result:

```
PASS
```

