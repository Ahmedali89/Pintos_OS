# Final Report for Project 2: User Programs

### Task 1 Changes:

- We parse the file name in `process_execute()` because processes are given names when they're created. This was needed to print the correct output for the test cases.
-   Changes in the algorithm:
    + Instead of setting up the arguments of the process in `load()` function, we do that in `start_process()` instead. We do so because we need to give `load()` the correct filename so it can open the executable, and we need to wait for the stack to be completely set before pushing arguments to the stack.
    

### Task 2 changes:
- For each of the `struct wait_status`, we added an extra variable, `int load_success` which takes value `1` if the child process successfully loaded the executable, and `0` if some error occurred. We use this to ensure that the parent process can set the exit code to `-1` when its child has an error during loading.
- In `exception.c`, we make sure we call a function in `syscall.c` `exit(int status)` that frees all allocated memory for `struct wait_status` and data structures used on Task 3.
- We created a function`void exit_if_invalid_args(void *, size_t)` that validates the addresses starting at the given pointer, ending at the pointer's address + size. We use this function to validate all system call arguments. 
- Helper functions for `wait()`, `exit()`, `exec()`, `halt()`, and `practice()`were added. These are called on `syscall_handler()`.

### Task 3 changes:
- Same as Task 2, we added the function called `void exit_if_invalid_args(void *, size_t)` to check if the arguments given to the function is valid in order to proceed to the syscall from kernel; if the arguments are not valid, we call `exit(-1)` which will exit with status code -1.
- Also, we set the return values of all the kernel syscall functions to f->eax.
- We decided not to add the array of file descriptors to the struct thread but instead we keep the list of all file pointers with their corresponding file descriptors for each thread. The reason for this change is because we decides that each thread should have its own counter for increasing file descriptor, instead of having the next fd global for all threads.
- Changes made in the helper functions:
    +  Read:
        + If fd equasl to 0 (meaning stdin), call `input_getc()` and return the result of that function.
        + If fd equals to 1, return -1.
        + If fd > 1 and the current thread does not have any corresponding fd, call exit with status code -1.
        + If fd > 1 and the fd is valid for the current thread, we call `file_read(file_name, buf, size)`
    +  Write:
        + If fd equals to 1 (meaning stdout), call `putbuf(buf, size)` and return the result of that function.
        + If fd equals to 0, return -1.
        + If fd > 1 and the current thread does not have any corresponding fd, call exit with status code -1.
        + If fd > 1 and the fd is valid for the current thread, we call `file_write(file_name, buf, size)`


### Test cases:
- Test cases were not included in the initial design doc. However, they are being added to code as part of the implementation stage. Look at the "Testing Report" below.


### Reflection:

**What did go well and what did go wrong in the design?**

- Writing the system calls was pretty straightforward as we followed our design. Most of the Task 3 work was repetitive, essentially calling functions in `file.c` and `filesys.c`.

- It took us a while to figure out what to do when a process encounters an exception (i.e. page fault). 
    
-   Creating  tests cases was not an easy process because we had to go through all the tests and try to figure out the structure of forming correct test case. Not to mention we had to read the specs again and compare the tests cases to figure out the parts that were not tested.

**Participation of group:**

-   Denny: code review, brainstorming, coding.
    
-   Khang: code review, brainstorming, coding.
    
-   (Elvis) Kin: code review, brainstorming, coding.
    
-   Ahmed: code review, brainstorming, coding.
    

We feel that all members contributed equally to the project. We made it a priority to do group coding rather than splitting the tasks among members and merging the work later. We took turns coding in the same room, using a single computer. Our workflow was as follows: one person writes code and the rest checks the code's logic and correctness. Upon finding a bug, we all start debugging the code on different machines and whoever finds the bug, fixes it and commits the changes. Then, we all come back as a group to discuss the bug we found and document its fix.

--------------------------------------------------------






# Testing Report:

  

### Test Case 1:

**Provide a description of the feature your test case is supposed to test.**

-   Test case files: ```rm-open.c```
    
The test case verifies that any process can not reopen a removed file, and if the process tries to do so, the open function should exit with -1 because the file does not exist anymore.

**Provide an overview of how the mechanics of your test case work, as well as a qualitative description of the expected output.**

  
Each process has an independent set of file descriptors, so when a process delete a file, it should not be able to reopen this removed file again. Therefore, the second open function that is called on the removed file should return -1. The test make sure the value is less than 0.
    

**Provide the output of your own Pintos kernel when you run the test case. Please copy the full raw output file from userprog/build/tests/userprog/your-test-1.output as well as the raw results from userprog/build/tests/userprog/your-test-1.result.**

  

-   ```rm-open.c``` :
    
```\
char buf1[1234];
void
test_main (void)
{
    const char *file_name = "deleteme";
    int fd;
    CHECK (create (file_name, sizeof buf1), "create "%s"", file_name);

    CHECK ((fd = open (file_name)) > 1, "open "%s"", file_name);

    CHECK (remove (file_name), "remove "%s"", file_name);

    CHECK ((fd = open (file_name)) < 0, "failed open "%s"", file_name);
} 
```
  

- ```rm-open.output``` :
```\

Executing rm-open :

(rm-open) begin

(rm-open) create "deleteme"

(rm-open) open "deleteme"

(rm-open) remove "deleteme"

(rm-open) failed open "deleteme"

(rm-open) end

rm-open: exit(0)

```
  

- ```rm-open.result``` :
```\
PASS
```

**Identify two non-trivial potential kernel bugs, and explain how they would have affected your output of this test case. You should express these in this form: “If your kernel did X instead of Y, then the test case would output Z instead.”. You should identify two different bugs per test case, but you can use the same bug for both of your two test cases. These bugs should be related to your test case (e.g. “If your kernel had a syntax error, then this test case would not run.” does not count).**

  This question need to be answered


1. if the ```open()``` does not return -1 then the test will fails
    
2. if the `remove()` does not remove the file when called, the test will fails. 

### Test Case 2:

  

**Provide a description of the feature your test case is supposed to test.**

-   Test case files: `wait-nested.c` `child-nested.c` `child-loop.c`
    

Since children are not inherited. Then if there is a process A spawns child B and B spawns child process C, then A cannot  wait for C, even if B is dead. The function call ```wait(C)``` made by process A must fail. Similarly, orphaned processes are not assigned to a new parent if their parent process exits before they do.Thus, this test Case verifies this point.

  

**Provide an overview of how the mechanics of your test case work, as well as a qualitative description of the expected output.**

  

-   Assume we have three processes:
    

    process A: parent process which runs ```test_main``` function below.

    process B: child process which runs ```child-nested``` file.

    process C: grandchild process which runs ```child-loop``` file.

The test verifies if A does not wait for C after B exits as mentioned in the project specs

  

**Provide the output of your own Pintos kernel when you run the test case. Please copy the full raw output file from ```userprog/build/tests/userprog/your-test-1.output``` as well as the raw results from ```userprog/build/tests/userprog/your-test-1.result```.**

  

-   wait-nested.c:    run by process A
    

```\
void
test_main (void)
{
  pid_t grandchild;
  pid_t pid;
  msg("PROCESS A STARTS");
  pid_t child = exec ("child-nested");
  grandchild = wait(child);
  CHECK(grandchild > -1, "A WAITS FOR B: pid = %d",(long)grandchild);
  msg("B EXITS");
  pid = wait(grandchild);
  CHECK((pid == -1), "A WAITS FOR C, A SHOULD EXIT WITH   EXITCODE = %d", (long)pid);
  msg("A EXITS");

}
```

  
  
  

- ```child-nested.c```:  run by process B

```\
const char *test_name = "child-nested";

int
main (void)
{
    msg ("PROCESS B STARTS");

    pid_t child = exec ("child-loop");

    msg("B EXITS");

    return child;
}

```

  

- ```child-loop.c```:    run by process C

```\
const char* test_name = "child-loop";
int
main (void)

{
     msg("PROCESS C STARTS");

     int count = 0;

     while(count < 10000000000)

          count++;

     msg("PROCESS C EXITS");

    return 55;
}
```

  

- ```wait-nested.output```:

```\
Executing 'wait-nested':

(wait-nested) begin
(wait-nested) PROCESS A STARTS
(child-nested) PROCESS B STARTS
(child-loop) PROCESS C STARTS
(child-nested) B EXITS
child-nested: exit(5)
(wait-nested) A WAITS FOR B: pid = 5
(wait-nested) B EXITS
(wait-nested) A WAITS FOR C, A SHOULD EXIT WITH EXITCODE = -1
(wait-nested) A EXITS
(wait-nested) end
```

  

- ```wait-nested.result```: 
```\
  PASS
```

**Identify two non-trivial potential kernel bugs, and explain how they would have affected your output of this test case. You should express these in this form: “If your kernel did X instead of Y, then the test case would output Z instead.”. You should identify two different bugs per test case, but you can use the same bug for both of your two test cases. These bugs should be related to your test case (e.g. “If your kernel had a syntax error, then this test case would not run.” does not count).**
    
1.  If A does not wait for B the tests will also fails.

2.  If the EXITCODE of the function call ```wait(grandchild)``` made by A does not equal to -1, the test must fails.



**Tell us about your experience writing tests for Pintos. What can be improved about the Pintos testing system? (There’s a lot of room for improvement.) What did you learn from writing test cases?**

  

-   We had to go over all the test and understand how things work. Then we review the specs of the project to identify all the features that were mentioned on the project specs, yet they were not tested in the general testing. We tried to look for the most important edge cases that were not tested at all.
    
-   In term of improvement, we think writing tests is a very important area, and the class should focus more on it. Students do not get to learn this skills at all, and we think that it should be taught in the class. At least have some discussions sections to cover it.  
    


