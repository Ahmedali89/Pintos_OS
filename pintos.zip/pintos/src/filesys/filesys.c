

#include "filesys/filesys.h"
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include "filesys/file.h"
#include "filesys/free-map.h"
#include "filesys/inode.h"
#include "filesys/directory.h"
#include "filesys/cache.h"
#include "threads/malloc.h"

/* Partition that contains the file system. */
struct block *fs_device;

static void do_format (void);
 

/* Initializes the file system module.
   If FORMAT is true, reformats the file system. */
void
filesys_init (bool format)
{
  fs_device = block_get_role (BLOCK_FILESYS);
  if (fs_device == NULL)
    PANIC ("No file system device found, can't initialize file system.");

  inode_init ();
  free_map_init ();

  if (format)
    do_format ();

  free_map_open ();
}

/* Shuts down the file system module, writing any unwritten data
   to disk. */
void
filesys_done (void)
{ 
  cache_reset();
  free_map_close ();
}

/* Creates a file named NAME with the given INITIAL_SIZE.
   Returns true if successful, false otherwise.
   Fails if a file named NAME already exists,
   or if internal memory allocation fails. */
bool
filesys_create (const char *name, off_t initial_size, int isdir)
{
  bool success = 0;
  block_sector_t inode_sector = 0;

  struct dir * parent_dir = (struct dir *) malloc(get_dir_size());
  char * valid;
  struct dir * cwd;
  if (thread_current()->cwd == NULL) {
    thread_current()->cwd = dir_open_root();
  }
  cwd = dir_reopen(thread_current()->cwd);
  valid = get_dir(cwd, name, &parent_dir);
  
  if (valid == NULL) {
    if (parent_dir != NULL && dir_inumber(thread_current()->cwd) != dir_inumber(parent_dir)) {
      dir_close(parent_dir);
    }
    inode_close(dir_get_inode(cwd));
    return false;
  }
  else {
    success = (parent_dir != NULL
                    && free_map_allocate (1, &inode_sector)
                    && inode_create (inode_sector, initial_size, isdir)
                    && dir_add (parent_dir, valid, inode_sector));
  }
  if (!success && inode_sector != 0) {
    free_map_release (inode_sector, 1);
  } else {
    if (isdir) {
      struct dir* target_dir = dir_open(inode_open(inode_sector));
      dir_add(target_dir, ".", inode_sector);
      dir_add(target_dir, "..", dir_inumber(parent_dir));
      dir_close(target_dir);
    }
  }

  if (parent_dir != NULL && dir_inumber(thread_current()->cwd) != dir_inumber(parent_dir)) {
    dir_close(parent_dir);
  }
  inode_close(dir_get_inode(cwd));
  return success;
}

bool
filesys_chdir(const char *path) 
{
  bool success = 0;
  struct inode * file;
  struct dir * parent_dir = (struct dir *) malloc(get_dir_size());
  char * target_dir;
  struct dir * cwd;
  if (thread_current()->cwd == NULL) {
    thread_current()->cwd = dir_open_root();
  }
  cwd = dir_reopen(thread_current()->cwd);
  target_dir = get_dir(cwd, path, &parent_dir);
  
  if (target_dir != NULL && 
      dir_lookup(parent_dir, target_dir, &file) && 
      inode_is_dir(file)) {
        inode_close(dir_get_inode(cwd));
        thread_current()->cwd = dir_open(file);
        success = 1;
      }
  if (parent_dir != NULL && dir_inumber(thread_current()->cwd) != dir_inumber(parent_dir)) {
    dir_close(parent_dir);
  }
  return success;
}


/* Opens the file with the given NAME.
   Returns the new file if successful or a null pointer
   otherwise.
   Fails if no file named NAME exists,
   or if an internal memory allocation fails. */
struct file *
filesys_open (const char *name)
{
  struct inode *inode = NULL;
  if (thread_current()->cwd == NULL) {
    thread_current()->cwd = dir_open_root();
  }
  struct dir * parent_dir = (struct dir *) malloc(get_dir_size());
  char * file_ = get_dir(thread_current()->cwd, name, &parent_dir);

  if (file_ != NULL && parent_dir != NULL) {
    dir_lookup(parent_dir, file_, &inode);
  }

  if (parent_dir != NULL && dir_inumber(thread_current()->cwd) != dir_inumber(parent_dir)) {
    dir_close(parent_dir);
  }
  return file_open (inode);
}

/* Deletes the file named NAME.
   Returns true if successful, false on failure.
   Fails if no file named NAME exists,
   or if an internal memory allocation fails. */
bool
filesys_remove (const char *name)
{
  struct dir * cwd;
  if (thread_current()->cwd == NULL) {
    thread_current()->cwd = dir_open_root();
  }
  cwd = dir_reopen(thread_current()->cwd);
  bool success = false;
  struct dir * parent_dir = (struct dir *) malloc(get_dir_size());
  char * file_ = get_dir(cwd, name, &parent_dir);
  if (file_ != NULL && parent_dir != NULL) {
    success = dir_remove (parent_dir, file_);
  }
  if (parent_dir != NULL && dir_inumber(thread_current()->cwd) != dir_inumber(parent_dir)) {
    dir_close(parent_dir);
  }
  inode_close(dir_get_inode(cwd));
  return success;
}


/* Formats the file system. */
static void
do_format (void)
{
  printf ("Formatting file system...");
  free_map_create ();
  if (!dir_create (ROOT_DIR_SECTOR, 16)) 
    PANIC ("root directory creation failed");
  
  /* Project 3 Task 3 Starts Here */
  dir_add(dir_open_root(), ".", ROOT_DIR_SECTOR);
  dir_add(dir_open_root(), "..", ROOT_DIR_SECTOR);
  /* Project 3 Task 3 Ends Here */

  free_map_close ();
  printf ("done.\n");
}

