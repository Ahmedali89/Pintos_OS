#ifndef FILESYS_CACHE_H
#define FILESYS_CACHE_H
#include "devices/block.h"
#include "threads/synch.h"


void cache_init(void); 											/* Initializes the cache and its entries. */
struct cache_block * find_block(block_sector_t); 				/* Finds cache block associated with the disk sector. If not in cache, fetches it from disk. */
size_t cache_read(block_sector_t, uint8_t *, size_t, size_t); 	/* Reads SIZE bytes from the cache block into BUF starting at OFFset. */
size_t cache_write(block_sector_t, uint8_t *, size_t, size_t);  /* Writes SIZE bytes to the cache block starting at OFFset from BUF. */

void cache_reset(void); 	   
size_t get_Cache_Misses(void);
size_t get_Cache_Hits(void);

#endif