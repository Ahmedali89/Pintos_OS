#include "cache.h"
#include "stdbool.h"
#include "filesys/filesys.h"
#include "lib/string.h"


#define NUM_SECTORS 64



struct cache_block {
    uint8_t data[BLOCK_SECTOR_SIZE];   	/* Contains the actual block to be cached. */
    block_sector_t sector;             	/* Disk sector this block belongs to. */
    int ref_count;                     	/* Number of threads currently using this block. */
    bool used;                         	/* Use-bit for clock algorithm */
    bool dirty;                        	/* 1 if block was modified ever since brought from cache, 0 otherwise. */
    bool valid;                        	/* 1 if this block is a valid block, 0 otherwise. */
    struct lock block_lock;            	/* Lock to be acquired before changing entry's metadata.*/
};

struct cache_block cache[NUM_SECTORS];  /* Cache containing a maximum of 64 cache blocks. */
struct lock cache_lock;               	/* Synchronizes block accesses when loading and evicting blocks. */
static int hand;                      	/*  Clock Hand */

/* For cache statistics. */
size_t cache_misses;    				/* Cache misses. */
size_t cache_hits;       				/* Cache hits. */

static void cache_write_back(struct cache_block *block); /* Writes back block of data to the disk. */



void cache_init() {
	int i;
	for(i = 0; i < NUM_SECTORS; i++) {
		cache[i].ref_count = 0;
		cache[i].used = false;
		cache[i].dirty = 0;
		cache[i].valid = 0;
		lock_init(&cache[i].block_lock);
	}
	hand = 0;
	cache_hits = 0;
	cache_misses = 0;
	lock_init(&cache_lock);
}

struct cache_block * find_block(block_sector_t sector) {

	int old_hand = hand;
	lock_acquire(&cache_lock); 
	int i;
	for (i = 0; i < NUM_SECTORS; i++) {
		lock_acquire(&cache[i].block_lock);
		if (cache[i].valid == 1 && cache[i].sector == sector) {
			lock_release(&cache[i].block_lock);
			cache_hits++;
			return &cache[i];
		}
		lock_release(&cache[i].block_lock);
	}

	while (true) {
		lock_acquire(&cache[hand].block_lock);
		if (cache[hand].used == 1) {
			if (cache[hand].ref_count == 0) {
				cache[hand].used = 0;
			}
			lock_release(&cache[hand].block_lock);
		} else {
			
			if (cache[hand].dirty == 1) {
				cache_write_back(&cache[hand]);
			}
			block_read (fs_device, sector, cache[hand].data);
			cache[hand].valid = 1;
			cache[hand].used = 1;
			cache[hand].sector = sector;
			old_hand = hand;
			hand = (hand + 1) % NUM_SECTORS;
			lock_release(&cache[old_hand].block_lock);
			break;
		}	
		hand = (hand + 1) % NUM_SECTORS;
	}
	cache_misses++;
	return &cache[old_hand];
}

size_t cache_read(block_sector_t sector, uint8_t * buf, size_t size, size_t off) {
	struct cache_block * block = find_block(sector);
	lock_acquire(&block->block_lock);
	block->sector = sector;
	block->valid = 1;
	block->used = 1;
	block->ref_count += 1;
	lock_release(&cache_lock);
	memcpy(buf, block->data + off, size);
	block->ref_count -= 1;
	lock_release(&block->block_lock);
	return size;
}

size_t cache_write(block_sector_t sector, uint8_t * buf, size_t size, size_t off) {
	struct cache_block * block = find_block(sector);
	lock_acquire(&block->block_lock);
	block->sector = sector;
	block->valid = 1;
	block->used = 1;
	block->dirty = 1;
	block->ref_count += 1;
	lock_release(&cache_lock);
	memcpy(block->data + off, buf, size);
	block->ref_count -= 1;
	lock_release(&block->block_lock);
	return size;
}

static
void cache_write_back(struct cache_block* block) {
	if (block->valid == 0 || block->dirty == 0) {
		return;
	}
	block_write (fs_device, block->sector, block->data);
	block->dirty = 0;
}

void cache_reset() {
	int i;
	uint8_t zeros[BLOCK_SECTOR_SIZE];
	for (i = 0; i < NUM_SECTORS; i++) {
		cache_write_back(&cache[i]);
		memcpy(cache[i].data, zeros, BLOCK_SECTOR_SIZE);
		cache[i].sector = 0;
		cache[i].ref_count = 0;
		cache[i].used = false;
		cache[i].dirty = 0;
		cache[i].valid = 0;
	}
	hand = 0;
	cache_hits = 0;
	cache_misses = 0;
}

size_t get_Cache_Misses() {
	return cache_misses;
}
size_t get_Cache_Hits() {
	return cache_hits;
}
