#include "filesys/inode.h"
#include <list.h>
#include <debug.h>
#include <round.h>
#include <string.h>
#include "filesys/filesys.h"
#include "filesys/free-map.h"
#include "threads/malloc.h"
#include "threads/synch.h"
#include "filesys/cache.h"

/* Identifies an inode. */
#define INODE_MAGIC 0x494e4f44
#define NUM_DIRECT_PTRS 12
#define NUM_UNUSED_BLOCKS 111
#define NUM_DIRECT_PTRS_IN_INDIR_BLOCK 128


static struct lock free_map_lock;

struct indirect_block 
  {
    block_sector_t direct_ptrs[NUM_DIRECT_PTRS_IN_INDIR_BLOCK]; 
  };

/* On-disk inode.
   Must be exactly BLOCK_SECTOR_SIZE bytes long. */
struct inode_disk
  {
    off_t length;                                     /* File size in bytes. */
    bool isdir;                                       /* Is this inode a directory? */                    
    block_sector_t direct_ptrs[NUM_DIRECT_PTRS];      /* The first 12 sectors of the file go here. */
    block_sector_t indirect_ptr;                      /* Sector containing the indirect block. */
    block_sector_t doubly_indirect_ptr;               /* Sector containing the doubly indirect block. */
    unsigned magic;                                   /* Magic number. */
    uint32_t unused[NUM_UNUSED_BLOCKS];               /* Not used. */
  };

/* Returns the number of sectors to allocate for an inode SIZE
   bytes long. */
static inline size_t
bytes_to_sectors (off_t size)
{
  return DIV_ROUND_UP (size, BLOCK_SECTOR_SIZE);
}

/* In-memory inode. */
struct inode
  {
    struct list_elem elem;                            /* Element in inode list. */
    block_sector_t sector;                            /* Sector number of disk location. */
    int open_cnt;                                     /* Number of openers. */
    bool removed;                                     /* True if deleted, false otherwise. */
    int deny_write_cnt;                               /* 0: writes ok, 1: deny writes. */
    bool isdir;                                       /* True if current inode is for a directory, false otherwise. */
    block_sector_t direct_ptrs[NUM_DIRECT_PTRS];      /* The first 12 sectors of the file go here. */
    block_sector_t indirect_ptr;                      /* Sector containing the indirect block. */
    block_sector_t doubly_indirect_ptr;               /* Sector containing the doubly indirect block. */
    off_t length;                                     /* File size in bytes. */
    struct lock inode_lock;                           /* Makes sure extending a file is synchronized. */
  };

/* Returns the block device sector that contains byte offset POS
   within INODE.
   Returns -1 if INODE does not contain data for a byte at offset
   POS. */
static block_sector_t
byte_to_sector (const struct inode *inode, off_t pos)
{
  ASSERT (inode != NULL);

  if (pos > inode->length)
    return -1;

  uint8_t buf[BLOCK_SECTOR_SIZE];

  if (pos < BLOCK_SECTOR_SIZE * NUM_DIRECT_PTRS) 
  {
    return inode->direct_ptrs[pos / BLOCK_SECTOR_SIZE];

  } else if (pos < BLOCK_SECTOR_SIZE * (NUM_DIRECT_PTRS + NUM_DIRECT_PTRS_IN_INDIR_BLOCK)) { 

    
    cache_read(inode->indirect_ptr, buf, BLOCK_SECTOR_SIZE, 0);
    int direct_ptr_idx = (pos / BLOCK_SECTOR_SIZE) - NUM_DIRECT_PTRS;
    block_sector_t sector = ((struct indirect_block *) buf)->direct_ptrs[direct_ptr_idx];
    return sector;

  } else if (pos < BLOCK_SECTOR_SIZE *
     (NUM_DIRECT_PTRS + NUM_DIRECT_PTRS_IN_INDIR_BLOCK + 
      NUM_DIRECT_PTRS_IN_INDIR_BLOCK * NUM_DIRECT_PTRS_IN_INDIR_BLOCK)) {
    cache_read(inode->doubly_indirect_ptr, buf, BLOCK_SECTOR_SIZE, 0);
    
    int indirect_ptr_idx = ((pos / BLOCK_SECTOR_SIZE) - 
      NUM_DIRECT_PTRS - NUM_DIRECT_PTRS_IN_INDIR_BLOCK) /
      NUM_DIRECT_PTRS_IN_INDIR_BLOCK;
    
    block_sector_t indirect_ptr = ((struct indirect_block *) buf)->direct_ptrs[indirect_ptr_idx];
    
    cache_read(indirect_ptr, buf, BLOCK_SECTOR_SIZE, 0);
    int direct_ptr_idx =  ((pos / BLOCK_SECTOR_SIZE) - NUM_DIRECT_PTRS - 
      NUM_DIRECT_PTRS_IN_INDIR_BLOCK) % NUM_DIRECT_PTRS_IN_INDIR_BLOCK;
    
    block_sector_t sector = ((struct indirect_block *) buf)->direct_ptrs[direct_ptr_idx];
    return sector;
  }
  else
    return -1;
}

/* List of open inodes, so that opening a single inode twice
   returns the same `struct inode'. */
static struct list open_inodes;

static void
get_next_data_block (struct inode * inode, size_t *layer, size_t* singly_index, size_t *doubly_index) {
  
  size_t sectors = bytes_to_sectors(inode->length);

  if (sectors < NUM_DIRECT_PTRS) {
    *layer = 0;
    *singly_index = sectors;
    *doubly_index = 0;
  } else if (sectors < NUM_DIRECT_PTRS + NUM_DIRECT_PTRS_IN_INDIR_BLOCK) {
    sectors -= NUM_DIRECT_PTRS;
    *layer = 1;
    *singly_index = sectors;
    *doubly_index = 0;
  } else {
    sectors -= NUM_DIRECT_PTRS + NUM_DIRECT_PTRS_IN_INDIR_BLOCK;
    *layer = 2;
    *singly_index = sectors % NUM_DIRECT_PTRS_IN_INDIR_BLOCK;
    *doubly_index = sectors / NUM_DIRECT_PTRS_IN_INDIR_BLOCK;
  }
}

static bool
has_free_space (int count) {
  if (count == 0) {
    return 1;
  }
  
  size_t total_sector_needed = count;
  int temp = count - NUM_DIRECT_PTRS;
  
  if (temp > 0) {
    total_sector_needed++;
    temp -= NUM_DIRECT_PTRS_IN_INDIR_BLOCK;
  }
  if (temp > 0) {
    total_sector_needed++;
  }
  while (temp > 0) {
    total_sector_needed++;
    temp -= NUM_DIRECT_PTRS_IN_INDIR_BLOCK;
  }

  if (!free_map_allocate_helper(total_sector_needed)) {
    return 0;
  }
  return 1;
}

static bool 
allocate_helper (int count, struct inode * inode, 
                  struct inode_disk *disk_inode, int layer, 
                  int singly_index, int doubly_index) {
  int allocated;
  if (layer == 0) {
    for (allocated = 0; allocated < count && singly_index < NUM_DIRECT_PTRS;
            singly_index++, allocated++) {
      free_map_allocate(1, &disk_inode->direct_ptrs[singly_index]);
    }
    if (inode != NULL) {
      memcpy(&inode->direct_ptrs, &disk_inode->direct_ptrs,
       NUM_DIRECT_PTRS * sizeof(block_sector_t));
    }
    count -= allocated;
    if (count > 0) {
      // Indirect pointer.
      free_map_allocate(1, &disk_inode->indirect_ptr);
      if (inode != NULL)
        inode->indirect_ptr = disk_inode->indirect_ptr;
      allocate_helper (count, inode, disk_inode, 1, 0, 0);
    }

  } else if (layer == 1) {
    struct indirect_block * i_b = (struct indirect_block *) malloc(sizeof(struct indirect_block));
    cache_read(disk_inode->indirect_ptr, (uint8_t *)i_b, BLOCK_SECTOR_SIZE, 0);
    for (allocated = 0; allocated < count && singly_index < NUM_DIRECT_PTRS_IN_INDIR_BLOCK; 
        singly_index++, allocated++) {
      free_map_allocate(1, &i_b->direct_ptrs[singly_index]);
    }
    cache_write(disk_inode->indirect_ptr, (uint8_t *)i_b, BLOCK_SECTOR_SIZE, 0);
    free(i_b);

    if (inode != NULL)
      inode->indirect_ptr = disk_inode->indirect_ptr;
    count -= allocated;
    if (count > 0) {
      // Doubly-indirect pointer.
      free_map_allocate(1, &disk_inode->doubly_indirect_ptr);
      if (inode != NULL)
        inode->doubly_indirect_ptr = disk_inode->doubly_indirect_ptr;
      allocate_helper (count, inode, disk_inode, 2, 0, 0);
    } 
  } else if (layer == 2) {
    struct indirect_block * d_i_b = (struct indirect_block *) malloc(sizeof(struct indirect_block));
    cache_read(disk_inode->doubly_indirect_ptr, (uint8_t *)d_i_b, BLOCK_SECTOR_SIZE, 0);
    if (singly_index == 0) {
      free_map_allocate(1, &d_i_b->direct_ptrs[doubly_index]);
    }
    while (count > 0) {
      struct indirect_block * i_b2 = (struct indirect_block *) malloc(sizeof(struct indirect_block));
      cache_read(d_i_b->direct_ptrs[doubly_index], (uint8_t*)i_b2, BLOCK_SECTOR_SIZE, 0);

      for (allocated = 0; allocated < count && singly_index < NUM_DIRECT_PTRS_IN_INDIR_BLOCK;
        singly_index++, allocated++) {
        free_map_allocate(1, &i_b2->direct_ptrs[singly_index]);
      }
      cache_write(d_i_b->direct_ptrs[doubly_index++], (uint8_t *)i_b2, BLOCK_SECTOR_SIZE, 0);  
      count -= allocated;
      
      if (count > 0) {
        free_map_allocate(1, &d_i_b->direct_ptrs[doubly_index]);
      }
      singly_index = 0;
      free(i_b2);
    }
    cache_write(disk_inode->doubly_indirect_ptr, (uint8_t *)d_i_b, BLOCK_SECTOR_SIZE, 0);
    free(d_i_b);
    if (inode != NULL)
      inode->doubly_indirect_ptr = disk_inode->doubly_indirect_ptr;
    
  }
  return 1;
}

static void 
release_helper (int count, struct inode_disk * disk_inode) {
  int i;
  for (i = 0 ; i < count && i < NUM_DIRECT_PTRS; i++) {
    free_map_release (disk_inode->direct_ptrs[i], 1);
  }
  count -= i;
  if (count <= 0) {
    return;
  }

  struct indirect_block * i_b = (struct indirect_block *)malloc(sizeof(struct indirect_block));
  cache_read (disk_inode->indirect_ptr, (uint8_t *)i_b, BLOCK_SECTOR_SIZE, 0);

  for (i = 0 ; i < count && i < NUM_DIRECT_PTRS_IN_INDIR_BLOCK; i++) {
    free_map_release(i_b->direct_ptrs[i], 1);
  }
  free_map_release(disk_inode->indirect_ptr, 1);
  count -= i;
  free(i_b);

  if (count <= 0) {
    return;
  }

  struct indirect_block * d_i_b = (struct indirect_block *)malloc(sizeof(struct indirect_block));
  cache_read (disk_inode->doubly_indirect_ptr, (uint8_t *)d_i_b, BLOCK_SECTOR_SIZE, 0);
  int j = 0;
  while (count > 0) {
    struct indirect_block * i_b2 = (struct indirect_block *)malloc(sizeof(struct indirect_block));
    cache_read (d_i_b->direct_ptrs[j], (uint8_t *)i_b2, BLOCK_SECTOR_SIZE, 0);
    for (i = 0; i < count && i < NUM_DIRECT_PTRS_IN_INDIR_BLOCK; ++i) {
      free_map_release (i_b2->direct_ptrs[i], 1);
    }
    free_map_release (d_i_b->direct_ptrs[j++], 1);
    count -= i;
    free(i_b2);
  }
  free_map_release (disk_inode->doubly_indirect_ptr, 1);
  free(d_i_b);
}
/* ends here */

/* Initializes the inode module. */
void
inode_init (void)
{
  list_init (&open_inodes);
  lock_init (&free_map_lock);
}

/* Initializes an inode with LENGTH bytes of data and
   writes the new inode to sector SECTOR on the file system
   device.
   Returns true if successful.
   Returns false if memory or disk allocation fails. */
bool
inode_create (block_sector_t sector, off_t length, int isdir)
{
  struct inode_disk *disk_inode = NULL;
  bool success = false;

  ASSERT (length >= 0);

  /* If this assertion fails, the inode structure is not exactly
     one sector in size, and you should fix that. */
  ASSERT (sizeof *disk_inode == BLOCK_SECTOR_SIZE);

  disk_inode = calloc (1, sizeof *disk_inode);
  if (disk_inode != NULL)
    {
      size_t sectors = bytes_to_sectors (length);
      disk_inode->length = length;
      disk_inode->isdir = isdir;
      disk_inode->magic = INODE_MAGIC;

      lock_acquire (&free_map_lock);

      if (has_free_space(sectors) && allocate_helper (sectors, NULL, disk_inode, 0, 0, 0)) {
        cache_write (sector, (uint8_t *)disk_inode, BLOCK_SECTOR_SIZE, 0);
        success = true;
      }

      lock_release (&free_map_lock);
      free (disk_inode);
    }
  return success;
}

/* Reads an inode from SECTOR
   and returns a `struct inode' that contains it.
   Returns a null pointer if memory allocation fails. */
struct inode *
inode_open (block_sector_t sector)
{
  struct list_elem *e;
  struct inode *inode;

  /* Check whether this inode is already open. */
  for (e = list_begin (&open_inodes); e != list_end (&open_inodes);
       e = list_next (e))
    {
      inode = list_entry (e, struct inode, elem);
      if (inode->sector == sector)
        {
          inode_reopen (inode);
          return inode;
        }
    }

  /* Allocate memory. */
  inode = malloc (sizeof *inode);
  if (inode == NULL)
    return NULL;

  /* Initialize. */
  list_push_front (&open_inodes, &inode->elem);
  inode->sector = sector;
  inode->open_cnt = 1;
  inode->deny_write_cnt = 0;
  inode->removed = false;

  struct inode_disk * disk_inode = (struct inode_disk *)malloc(sizeof(struct inode_disk));
  cache_read(sector, (uint8_t*) disk_inode, BLOCK_SECTOR_SIZE, 0);
  inode->length = disk_inode->length;
  memcpy(&inode->direct_ptrs, &disk_inode->direct_ptrs, NUM_DIRECT_PTRS * sizeof(block_sector_t));
  inode->indirect_ptr = disk_inode->indirect_ptr;
  inode->doubly_indirect_ptr = disk_inode->doubly_indirect_ptr;

  inode->isdir = disk_inode->isdir;
  lock_init(&inode->inode_lock);
  free(disk_inode);

  return inode;
}

/* Reopens and returns INODE. */
struct inode *
inode_reopen (struct inode *inode)
{
  if (inode != NULL)
    inode->open_cnt++;
  return inode;
}

/* Returns INODE's inode number. */
block_sector_t
inode_get_inumber (const struct inode *inode)
{
  return inode->sector;
}

/* Closes INODE and writes it to disk.
   If this was the last reference to INODE, frees its memory.
   If INODE was also a removed inode, frees its blocks. */
void
inode_close (struct inode *inode)
{
  /* Ignore null pointer. */
  if (inode == NULL)
    return;

  /* Release resources if this was the last opener. */
  if (--inode->open_cnt == 0) {
    /* Remove from inode list and release lock. */
    list_remove (&inode->elem);

    /* Deallocate blocks if removed. */
    if (inode->removed) {
        free_map_release (inode->sector, 1);
        struct inode_disk * disk_inode = (struct inode_disk *) malloc(sizeof(struct inode_disk));
        cache_read (inode->sector, (uint8_t *)disk_inode, BLOCK_SECTOR_SIZE, 0);
        release_helper (bytes_to_sectors (inode->length), disk_inode);
        free(disk_inode);
    }
    free(inode);
  }
}

/* Marks INODE to be deleted when it is closed by the last caller who
   has it open. */
void
inode_remove (struct inode *inode)
{
  ASSERT (inode != NULL);
  inode->removed = true;
}

/* Reads SIZE bytes from INODE into BUFFER, starting at position OFFSET.
   Returns the number of bytes actually read, which may be less
   than SIZE if an error occurs or end of file is reached. */
off_t
inode_read_at (struct inode *inode, void *buffer_, off_t size, off_t offset)
{
  uint8_t *buffer = buffer_;
  off_t bytes_read = 0;

  if (offset > inode->length)
    return 0;

  while (size > 0)
    {
      /* Disk sector to read, starting byte offset within sector. */
      block_sector_t sector_idx = byte_to_sector (inode, offset);

      if (offset > inode->length) {
        return bytes_read;
      }

      int sector_ofs = offset % BLOCK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode_length (inode) - offset;
      int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
      int min_left = inode_left < sector_left ? inode_left : sector_left;

      /* Number of bytes to actually copy out of this sector. */
      int chunk_size = size < min_left ? size : min_left;
      if (chunk_size <= 0)
        break;

      cache_read(sector_idx, (uint8_t *)(buffer + bytes_read), chunk_size, sector_ofs);

      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_read += chunk_size;

    }
  return bytes_read;
}

/* Writes SIZE bytes from BUFFER into INODE, starting at OFFSET.
   Returns the number of bytes actually written, which may be
   less than SIZE if end of file is reached or an error occurs.
   (Normally a write at end of file would extend the inode, but
   growth is not yet implemented.) */
off_t
inode_write_at (struct inode *inode, const void *buffer_, off_t size,
                off_t offset)
{

  uint8_t* bounce = NULL;
  lock_acquire(&inode->inode_lock);

  const uint8_t *buffer = buffer_;
  off_t bytes_written = 0;

  if (inode->deny_write_cnt) {
    lock_release(&inode->inode_lock);
    return 0;
  }

  if (size + offset > inode_length(inode)) {
    lock_acquire (&free_map_lock);

    size_t new_sectors = bytes_to_sectors(size + offset) - bytes_to_sectors(inode_length(inode));
    if (!has_free_space(new_sectors)) {
      lock_release(&free_map_lock);
      lock_release(&inode->inode_lock);
      return 0;    
    }
    struct inode_disk * disk_inode = (struct inode_disk *) malloc(sizeof(struct inode_disk));
    
    cache_read(inode->sector, (uint8_t *)disk_inode, BLOCK_SECTOR_SIZE, 0);
    if (new_sectors > 0) {
      size_t layer = 0, singly_index = 0, doubly_index = 0;
      get_next_data_block (inode, &layer, &singly_index, &doubly_index);
      if (layer == 1 && singly_index == 0 && doubly_index == 0) {
        free_map_allocate(1, &disk_inode->indirect_ptr);
      } else if (layer == 2 && singly_index == 0 && doubly_index == 0) {
        free_map_allocate(1, &disk_inode->doubly_indirect_ptr);
      }
      allocate_helper(new_sectors, inode, disk_inode, layer, singly_index, doubly_index);
    }
    inode->length = size + offset;
    disk_inode->length = size + offset;
    cache_write(inode->sector, (uint8_t *)disk_inode, BLOCK_SECTOR_SIZE, 0);
    free(disk_inode);
    lock_release (&free_map_lock);
  }
  /* ends here */

  while (size > 0)
    {
      /* Sector to write, starting byte offset within sector. */
      block_sector_t sector_idx = byte_to_sector (inode, offset);

      int sector_ofs = offset % BLOCK_SECTOR_SIZE;

      /* Bytes left in inode, bytes left in sector, lesser of the two. */
      off_t inode_left = inode_length (inode) - offset;
      int sector_left = BLOCK_SECTOR_SIZE - sector_ofs;
      int min_left = inode_left < sector_left ? inode_left : sector_left;

      /* Number of bytes to actually write into this sector. */
      int chunk_size = size < min_left ? size : min_left;
      if (chunk_size <= 0)
        break;
      cache_write(sector_idx, (uint8_t *)(buffer + bytes_written), chunk_size, sector_ofs);

      /* Advance. */
      size -= chunk_size;
      offset += chunk_size;
      bytes_written += chunk_size;
    }

  lock_release(&inode->inode_lock);
  free(bounce);
  return bytes_written;
}

/* Disables writes to INODE.
   May be called at most once per inode opener. */
void
inode_deny_write (struct inode *inode)
{
  inode->deny_write_cnt++;
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
}

/* Re-enables writes to INODE.
   Must be called once by each inode opener who has called
   inode_deny_write() on the inode, before closing the inode. */
void
inode_allow_write (struct inode *inode)
{
  ASSERT (inode->deny_write_cnt > 0);
  ASSERT (inode->deny_write_cnt <= inode->open_cnt);
  inode->deny_write_cnt--;
}

/* Returns the length, in bytes, of INODE's data. */
off_t
inode_length (const struct inode *inode)
{
  return inode->length;
}

bool
inode_is_dir(struct inode *inode) {
  return inode->isdir;
}

int
inode_open_cnt(struct inode *inode) {
  return inode->open_cnt;
}


