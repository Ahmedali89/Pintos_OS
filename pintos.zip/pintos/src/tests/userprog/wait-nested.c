/* Assume we have three processes
process A: parent process which runs test_main function below
process B: child process which runs child-nested file
process C: grandchild process which runs child-loop file
the test verifeis if A does not wait for C after B exits as mentioned in the project specs
*/

#include <syscall.h>
#include "tests/lib.h"
#include "tests/main.h"

void
test_main (void)
{
	pid_t grandchild;
	pid_t pid;
  msg("PROCESS A STARTS");
  pid_t child = exec ("child-nested");
  grandchild = wait(child);
  CHECK(grandchild > -1, "A WAITS FOR B: pid = %ld", (long)grandchild);
  msg("B EXITS");
  pid = wait(grandchild);
  CHECK((pid == -1), "A WAITS FOR C, A SHOULD EXIT WITH EXITCODE = %d", (long)pid);
  msg("A EXITS");
}


