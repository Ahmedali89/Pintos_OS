/* Child process run by wait-nested, and the child create 
its own child to run child-loop test */

#include <stdio.h>
#include "tests/lib.h"
#include "tests/main.h"

const char *test_name = "child-nested";

int
main (void)
{
  msg ("PROCESS B STARTS");
  pid_t child = exec ("child-loop");
  msg("B EXITS");
  return child;
}
