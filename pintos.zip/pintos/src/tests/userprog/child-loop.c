/*Child process run by child-nested. This is the grandchild process
it runs a very long loop to make sure the parent process at the wait-nested
test exits before this process ends 
*/

#include <stdio.h>
#include "tests/lib.h"

const char* test_name = "child-loop";

int
main (void)
{
	msg("PROCESS C STARTS");
	int count = 0;
	while(count < 10000000000)
		count++;
	msg("PROCESS C EXITS");
  return 55;
}
