#include <random.h>
#include <stdlib.h>
#include <syscall.h>
#include "tests/lib.h"
#include "tests/main.h"


const char *test_name = "mcache_hits";

#define NUM_BLOCKS 64
#define SIZE_OF_BLOCK 512

static char buf[SIZE_OF_BLOCK];


/*

Test your buffer cache’s effectiveness by measuring its cache hit rate. First, reset the buffer cache.
Open a file and read it sequentially, to determine the cache hit rate for a cold cache. Then, close
it, re-open it, and read it sequentially again, to make sure that the cache hit rate improves.

*/

void 
test_main(void) {

	size_t expected_Bytes;
	size_t fd;
	size_t cold_Cache_hits, cold_Cache_totalaccesses, cold_Cache_hitRates;
	size_t hot_Cache_hits, hot_Cache_totalaccesses, hot_Cache_hitRates;
	int i =0;
	random_init (0);
	/*Write random Bytes*/
	random_bytes (buf, sizeof buf);

	CHECK (create ("TESTFILE", 0), "create \"TESTFILE\"");
	CHECK ((fd = open ("TESTFILE")) > 1, "open \"TESTFILE\"");

	msg("WRITING INTO TESTFILE");

	for(; i <= NUM_BLOCKS; i++)
	{
		expected_Bytes = write (fd, buf, SIZE_OF_BLOCK);
		if (expected_Bytes!= SIZE_OF_BLOCK)
			fail ("EXPECTED_BYTES:  %zu  IN TESTFILE ACTUAL WRITEN BYTES:  %zu", 
			    	1, expected_Bytes);
	}
	close (fd);

	msg("1st TIME OPENING TESTFILE TO MAKE SEQUENTIAL READ!!");
	CHECK ((fd = open ("TESTFILE")) > 1, "open \"TESTFILE\"");

	msg("RESETTING CACHE BUFFER!!");
	buffer_reset();
	i = 0;
	for (; i < NUM_BLOCKS; i++)
	{
		expected_Bytes = read (fd, buf, SIZE_OF_BLOCK);
		if (expected_Bytes != SIZE_OF_BLOCK)
		    fail ("EXPECTED_BYTES:  %zu  IN TESTFILE ACTUAL READ BYTES:  %zu", 
		    	SIZE_OF_BLOCK, expected_Bytes);
	}
	msg("CLOSING TESTFILE");
	

	msg("COLD CACHE: STATISTICS");
	cold_Cache_hits = buffer_stat (1);
	cold_Cache_totalaccesses = buffer_stat (0) + cold_Cache_hits;
	cold_Cache_hitRates = (cold_Cache_hits * 100) / cold_Cache_totalaccesses;
	close (fd);

	msg("2nd TIME REOPENING TESTFILE TO MAKE SEQUENTIAL READ!!");
	CHECK ((fd = open ("TESTFILE")) > 1, "open \"TESTFILE\"");

	
	for (i = 0; i < NUM_BLOCKS; i++)
	{
		expected_Bytes = read (fd, buf, SIZE_OF_BLOCK);
		if (expected_Bytes != SIZE_OF_BLOCK)
		    fail ("EXPECTED_BYTES:  %zu  IN TESTFILE ACTUAL READ BYTES:  %zu", 
		    	SIZE_OF_BLOCK, expected_Bytes);
	}

	msg("CLOSING TESTFILE");
	close (fd);

	/*RESOURCE: https://blog.stackpath.com/glossary/cache-hit-ratio/*/
	msg("REMOVING TESTFILE");
	remove ("TESTFILE");
	msg("HOT CACHE: STATISTICS");
	hot_Cache_hits =  buffer_stat (1);
	hot_Cache_totalaccesses = buffer_stat (0) + hot_Cache_hits;
	hot_Cache_hitRates  = ((hot_Cache_hits - cold_Cache_hits) * 100) / (hot_Cache_totalaccesses - cold_Cache_totalaccesses);
	
	if (hot_Cache_hitRates > cold_Cache_hitRates) {
		msg("PASS");
	} else {
		msg("FAIL");
	}
}
