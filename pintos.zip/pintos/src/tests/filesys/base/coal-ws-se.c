#include <random.h>
#include <stdlib.h>
#include <syscall.h>
#include "tests/lib.h"
#include "tests/main.h"

const char *test_name = "coal-ws-se";

#define NUM_BLOCKS 128
#define SIZE_OF_BLOCK 512

static char buf[SIZE_OF_BLOCK * NUM_BLOCKS];

/*
Test your buffer cache’s ability to coalesce writes to the same sector. Each block device keeps
a read_cnt counter and a write_cnt counter. Write a large file byte-by-byte (make the total
file size at least 64KB, which is twice the maximum allowed buffer cache size). Then, read it in
byte-by-byte. The total number of device writes should be on the order of 128 (because 64KB is
128 blocks)
*/

void 
test_main(void) {

	size_t expected_Bytes, write_cnt, old_write_cnt;
	size_t fd;
	int i = 1;
	
	random_init (0);
	random_bytes (buf, SIZE_OF_BLOCK * NUM_BLOCKS);
	
	CHECK (create ("TESTFILE", 0), "create \"TESTFILE\"");
	CHECK ((fd = open ("TESTFILE")) > 1, "open \"TESTFILE\"");
	
	msg("WRITING INTO TESTFILE..");
	old_write_cnt = (size_t) buffer_stat(3);
	for(; i <= (NUM_BLOCKS * SIZE_OF_BLOCK); i++)
	{
		expected_Bytes = write (fd, buf, 1);
		if (expected_Bytes!= 1)
			fail ("EXPECTED_BYTES:  %zu  IN \"%s\" ACTUAL WRITEN BYTES:  %zu", 
			    	1, "TESTFILE" , expected_Bytes);
	}
	msg("CLOSING TESTFILE...");
	close (fd);
	write_cnt = NUM_BLOCKS * SIZE_OF_BLOCK;
	msg("NUMBER OF WRITES ACCESSES WITHOUT CACHE: %zu", write_cnt);

	CHECK ((fd = open ("TESTFILE")) > 1, "open \"TESTFILE\"");
	msg("READING FROM TESTFILE..");
	i = 1;
	for(; i <= (NUM_BLOCKS * SIZE_OF_BLOCK); i++)
	{
		expected_Bytes = read (fd, buf, 1);
		if (expected_Bytes!= 1)
			fail ("EXPECTED_BYTES:  %zu  IN \"%s\" ACTUAL READ BYTES:  %zu", 
			    	1, "TESTFILE" , expected_Bytes);
	}
	msg("CLOSING TESTFILE...");
	close (fd);
	msg("NUMBER OF WRITES ACCESSES WITH CACHE: %zu ", (size_t)buffer_stat(3) - old_write_cnt);
	if((size_t)buffer_stat(3) - old_write_cnt < write_cnt) {
		msg("PASS");
	} else{
		msg("FAIL");
	}
}