/*

Test your buffer cache’s effectiveness by measuring its cache hit rate. First, reset the buffer cache.
Open a file and read it sequentially, to determine the cache hit rate for a cold cache. Then, close
it, re-open it, and read it sequentially again, to make sure that the cache hit rate improves.

*/

#include <random.h>
#include <stdlib.h>
#include <syscall.h>
#include "tests/lib.h"
#include "tests/main.h"
#include "tests/filesys/extended/syn-rw.h"

const char *test_name = "measuring-cache-hitRates";

#define NUM_BLOCKS 30
#define SIZE_OF_BLOCK 512

static char buf[SIZE_OF_BLOCK];

void 
test_main(void) {

	size_t expected_Bytes;
	size_t fd;
	size_t cold_Cache_hits,cold_Cache_totalHits,cold_Cache_hitRates;
	size_t hot_Cache_hits,hot_Cache_totalHits,hot_Cache_hitRates;
	int i =0;
	random_init (0);
	/*Write random Bytes*/
	random_bytes (buf, sizeof buf);
	
	msg("RESETTING CACHE BUFFER!!");
	buffer_reset ();

	msg("1st TIME OPENING \"%s\" TO MAKE SEQENTIAL READ!!", file_name);
	CHECK ((fd = open (file_name)) > 1, "open \"%s\"", file_name);
	msg("TESTFILE OPENED SUCCESSFULLY!!");
	for (; i < NUM_BLOCKS; i++)
	{
		expected_Bytes = read (fd, buf, SIZE_OF_BLOCK);
		if (expected_Bytes != SIZE_OF_BLOCK)
		    fail ("EXPECTED_BYTES:  %zu  IN \"%s\" ACTUAL READ BYTES:  %zu", 
		    	SIZE_OF_BLOCK, file_name , expected_Bytes);
	}
	msg("CLOSING \"%s\" .....", file_name);
	close (fd);



	msg("COLD CACHE: STATISTICS.....");
	cold_Cache_hits = buffer_stat (1);
	cold_Cache_totalHits = buffer_stat (0) + cold_Cache_hits;
	cold_Cache_hitRates = (cold_Cache_hits * 100) / cold_Cache_totalHits;

	msg("2nd TIME REOPENING \"%s\" TO MAKE SEQENTIAL READ!!", file_name);
	CHECK ((fd = open (file_name)) > 1, "open \"%s\"", file_name);
	msg("TESTFILE OPENED SUCCESSFULLY!!");
	for (i = 0; i < NUM_BLOCKS; i++)
	{
		expected_Bytes = read (fd, buf, SIZE_OF_BLOCK);
		if (expected_Bytes != SIZE_OF_BLOCK)
		    fail ("EXPECTED_BYTES:  %zu  IN \"%s\" ACTUAL READ BYTES:  %zu", 
		    	SIZE_OF_BLOCK, file_name , expected_Bytes);
	}

	msg("CLOSING \"%s\" .....", file_name);
	close (fd);

	msg("REMOVING TESTFILE....");
	remove ("TESTFILE");
	msg("HOT CACHE: STATISTICS.....");
	hot_Cache_hits = buffer_stat (1) ;
	hot_Cache_totalHits = buffer_stat (0) + hot_Cache_hits;
	hot_Cache_hitRates  = ((hot_Cache_hits - cold_Cache_hits) * 100) / (hot_Cache_totalHits - cold_Cache_totalHits);

	if (hot_Cache_hitRates > cold_Cache_hitRates) {
		msg("PASS");
	} else{
		msg("FAIL");
	}

}
