
#include "userprog/syscall.h"
#include "userprog/process.h"
#include "userprog/pagedir.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "filesys/filesys.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/synch.h"
#include "lib/kernel/console.h"
#include "lib/kernel/list.h"
#include "lib/string.h"
#include "filesys/file.h"
#include "filesys/directory.h"
#include "filesys/inode.h"
#include "filesys/cache.h"
#include "devices/block.h"

#define FILE 0
#define DIRECTORY 1

static void syscall_handler (struct intr_frame *);
static void exit_if_invalid_args(void * arg, size_t size);
static struct file* get_file_from_fd(int fd);
static void close_all_files(void);


/* YOUR TASK 3 CODE STARTS HERE. */
static void halt(void);
static void close(int fd);
static int practice(int i);
static bool create(char* name, unsigned int initial_size);
static bool remove(char* name);
static unsigned int tell(int fd);
static int filesize(int fd);
static void seek(int fd, unsigned pos);
static int open(char* name);
static int read(int fd, char* buf, unsigned int size);
static int write(int fd, char* buf, unsigned int size);
static void remove_file(int fd);
static tid_t exec(char* name);
static int wait(tid_t child_tid);
static void exit(int status);
/* YOUR TASK 3 CODE ENDS HERE. */

/*PROJECT 3 TASK 2 STARTS HERE*/

static int inumber(int fd); 
static bool chdir (const char *dir);
static bool mkdir (const char *dir);
static bool readdir (int fd, char *name);
static bool isdir (int fd);

/*PROJECT 3 TASK 2 ENDS HERE*/

void
syscall_init (void)
{
    intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void 
exception_thrown(int status) 
{
    exit(status);
}


/*
 *    Validates `ptr`. Check that:
 *    1. `arg` is not NULL
 *    2. `arg` to `arg + size` are all in user's virtual address space.
 *     3. `arg` has a valid mapping to a physical address.
 *    Exits if any of the checks fail. Returns if successful.
 */
static void
exit_if_invalid_args(void * arg_, size_t size)
{
    uint32_t* arg = arg_;
    if (arg == NULL) {
        exit(-1);
    }
    if (!is_user_vaddr(arg) || !is_user_vaddr((uint8_t *)arg + size)) {
        exit(-1);
    }
    if (!pagedir_get_page (thread_current()->pagedir, arg) || !pagedir_get_page (thread_current()->pagedir, (uint8_t *)arg + size)) {
        exit(-1);
    }
}

static struct file* get_file_from_fd(int fd) {
    struct list_elem * e;
    struct list *file_list = &thread_current()->file_list;
    for (e = list_begin(file_list); e != list_end(file_list); e = list_next(e)) {
        struct file_list_elem * file_elem_ = list_entry(e, struct file_list_elem, file_elem);
        if (file_elem_->fd == fd) {
            return file_elem_->file;
        }
    }
    return NULL;
}

static void close_all_files() {
    struct list_elem * e;
    struct list *file_list = &thread_current()->file_list;

    for (e = list_begin(file_list); e != list_end(file_list); e = list_next(e)) {
        struct file_list_elem * file_elem = list_entry(e, struct file_list_elem, file_elem);
        if (file_elem->file) {
            if (file_is_dir(file_elem->file))
                dir_close((struct dir *)file_elem->file);
            else 
                file_close(file_elem->file);
        }
    }
    while (!list_empty(file_list)) {
        e = list_begin(file_list);
        struct file_list_elem * file_elem = list_entry(e, struct file_list_elem, file_elem);
        list_remove(e);
        free(file_elem);
    }
}


static void
syscall_handler (struct intr_frame *f)
{
    uint32_t* args = ((uint32_t*) f->esp);
    exit_if_invalid_args(args, 4);
    char *name, *buf;
    int fd;
    size_t size;
    unsigned pos;
    char* dir;

    switch (args[0]) {
        case SYS_HALT:
            halt();
            break;
        case SYS_EXIT:
            f->eax = args[1];
            exit(args[1]);
            break;
        case SYS_EXEC:
            name = (char *)args[1];
            exit_if_invalid_args(name, sizeof(char *));
            f->eax = exec(name);
            break;
        case SYS_WAIT:
            f->eax = wait(args[1]);
            break;
        case SYS_CREATE:
            name = (char *)args[1];
            size = (size_t)args[2];
            exit_if_invalid_args(name, 4);
            f->eax = create(name, size);
            break;
        case SYS_REMOVE:
            name = (char *)args[1];
            exit_if_invalid_args(name, 4);
            f->eax = remove(name);
            break;
        case SYS_OPEN:
            name = (char *)args[1];
            exit_if_invalid_args(name, sizeof(char *));
            f->eax = open(name);
            break;
        case SYS_FILESIZE:
            fd = (int)args[1];
            f->eax = filesize(fd);
            break;
        case SYS_READ:
            fd = (int)args[1];
            buf = (char *)args[2];
            size = (size_t) args[3];
            exit_if_invalid_args(buf, size);
            f->eax = read(fd, buf, size);
            break;
        case SYS_WRITE:
            fd = (int)args[1];
            buf = (char *)args[2];
            size = (size_t) args[3];
            exit_if_invalid_args(buf, size);
            f->eax = write(fd, buf, size);
            break;
        case SYS_SEEK:
            fd = (int)args[1];
            pos = (unsigned)args[2];
            seek(fd, pos);
            break;
        case SYS_TELL:
            fd = (int)args[1];
            f->eax = tell(fd);
            break;
        case SYS_CLOSE:
            fd = (int)args[1];
            close(fd);
            break;
        case SYS_PRACTICE:
            f->eax = practice(args[1]);
            break;
        case SYS_INUMBER:
            fd = (int) args[1];
            f->eax = inumber(fd);
            break;
        case SYS_CHDIR:
            dir = (char *) args[1];
            f->eax = chdir(dir);
            break;
        case SYS_MKDIR:
            dir = (char *) args[1];
            f->eax = mkdir(dir);
            break;
        case SYS_READDIR:
            fd = (int) args[1];
            dir = (char *) args[2];
            f->eax = readdir(fd, dir);
            break;
        case SYS_ISDIR:
            fd = (int) args[1];
            f->eax = isdir(fd);
            break;
        case SYS_CACHE_STAT:
            if ((int)args[1] == 0)
                f->eax = get_Cache_Misses();
            else if ((int)args[1] == 1) 
                f->eax = get_Cache_Hits();   
            else if ((int)args[1] == 2) 
                f->eax = get_read_cnt(fs_device);
            else if ((int)args[1] == 3)
                f->eax = get_write_cnt(fs_device);
            break;
        case SYS_CACHE_RESET:
            cache_reset();
            break;
    }
}

/*PROJEDT3 TASK 2 & 3 START HERE*/
static int inumber(int fd) {
    struct file* file = get_file_from_fd(fd);
    int inumber;
    if (!file_is_dir(file)) {
        inumber = file_inumber(file);
    } else {
        inumber = dir_inumber((struct dir *)file); 
    }
    return inumber;
}


static bool chdir (const char *dir) {
    return filesys_chdir(dir);
}   

static bool mkdir (const char *dir) {
    size_t initial_size = 0;
    bool success = filesys_create(dir, initial_size, DIRECTORY);
    return success;
}

static bool readdir (int fd, char *name) {
    bool success = 0;
    struct file * file = get_file_from_fd(fd);
    if (file_is_dir(file)) {
        success = dir_readdir((struct dir *) file, name);
    } 
    return success;
}

static bool isdir (int fd) {
    struct file* file = get_file_from_fd(fd);
    return file_is_dir(file);
}

/* PROJECT3 TASK 2 & 3 END HERE*/
static void exit(int status) {
    struct thread *curr_thread = thread_current();
    printf("%s: exit(%d)\n", curr_thread->name, status);
    cache_reset();
    close_all_files();

    thread_current()->wait_status->exit_code = status;
    // Iterate through children list and change the wait status;
    struct list_elem * e;
    struct list * children_status = &thread_current()->children_status;
    for (e = list_begin(children_status); e != list_end(children_status); e = list_next(e)) {
        struct wait_status * wait_status = list_entry(e, struct wait_status, status_elem);
        lock_acquire(&wait_status->lock);
        wait_status->ref_count--;
        if (wait_status->ref_count == 0) {
            e = list_prev(e);
            list_remove(list_next(e));
            lock_release(&wait_status->lock);
            free(wait_status);
        } else {
            lock_release(&wait_status->lock);
        }
    }
    thread_exit();
}
static void halt() {
    shutdown_power_off();
}

static void close(int fd) {
    if (fd == 0 || fd == 1) {
        return;
    }
    struct file *file = get_file_from_fd(fd);
    if (file == NULL) {
        return;
    }
    /*PROJECT3 TASK3 START HERE*/
    file_close(file); 
    /*END HERE*/
    remove_file(fd);
}

static void remove_file(int fd) {
    struct list_elem * e;
    struct list file_list = thread_current()->file_list;
    for (e = list_begin(&file_list); e != list_end(&file_list); e = list_next(e)) {
        struct file_list_elem * file_elem = list_entry(e, struct file_list_elem, file_elem);
        if (file_elem->fd == fd) {
            list_remove(e);
            free(file_elem);
            break;
        }
    }
}

static int practice(int i UNUSED) {
    return i + 1;
}

static bool create(char* name, unsigned int initial_size) {
    bool success = filesys_create(name, initial_size, FILE);
    return success;
}

static bool remove(char* name) {

    bool success = filesys_remove(name);

    return success;
}

static unsigned int tell(int fd) {

    struct file* file = get_file_from_fd(fd);
    if (file == NULL) {

        return 0;
    }
    unsigned int offset = file_tell(file);

    return offset;
}

static void seek(int fd, unsigned pos) {

    struct file* file = get_file_from_fd(fd);
    if (file != NULL) {
        file_seek(file, pos);
    }

}

static int filesize(int fd) {

    struct file* file = get_file_from_fd(fd);
    if (file == NULL) {
        return 0;
    }
    int length = file_length(file);

    return length;
}

static int open(char* name) {
    int fd;

    struct file* file = filesys_open(name);
    if (!file) {
        fd = -1;
    } else {
        struct file_list_elem *e = (struct file_list_elem *) malloc(sizeof(struct file_list_elem));
        e->file = file;
        e->fd = thread_current()->nextfd++;
        list_push_back(&thread_current()->file_list, &e->file_elem);
        fd = e->fd;
    }
    return fd;
}

static int read(int fd, char* buf, unsigned int size) {
    int length = -1;
    
    if (fd == 0) {
        length = input_getc();
    } else if (fd > 1) {
        struct file* file = get_file_from_fd(fd);
        if (file != NULL) {
            length = file_read (file, buf, size);
        } else {
            exit(-1);
        }
    }

    return length;
}

static int write(int fd, char* buf, unsigned int size) {
    int length = -1;
    if(fd == 1) {
        length = size;
        putbuf(buf, size);
    } else if (fd > 1) {
        struct file* file = get_file_from_fd(fd);
        if (file != NULL) {
            if (is_deny_write(file) == 0)
                length = file_write(file, buf, size);
        } else {
            exit(-1);
        }
    }
    return length;
}

static tid_t exec(char* name) {
    return process_execute(name);
}
static int wait(tid_t child_tid) {
    return process_wait(child_tid);
}
