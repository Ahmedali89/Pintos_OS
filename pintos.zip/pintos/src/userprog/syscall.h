#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

struct inode;

void syscall_init (void);
void exception_thrown(int status);

#endif /* userprog/syscall.h */
